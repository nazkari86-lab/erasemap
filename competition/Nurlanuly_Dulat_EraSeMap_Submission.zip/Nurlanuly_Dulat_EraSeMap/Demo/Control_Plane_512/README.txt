Run: erasemap bank-control-plane serve --port 8765
Then open: http://127.0.0.1:8765
This is a local synthetic demo; no real customer or bank is connected.
